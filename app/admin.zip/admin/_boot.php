<?php
// =========================================================================
// SoulSync Admin — bootstrap, session, and auth guard.
// Now part of soulpages: authenticated by the SAME soulpages admin login
// (same site, shared session). No separate SoulSync login / SSO anymore.
//   role 'admin'  → owner (sees everything)
//   role 'manager'→ manager (restricted sections hidden)
// =========================================================================
date_default_timezone_set('Asia/Kolkata'); // IST — admin dates/date-pickers flip at local midnight
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

require_once __DIR__ . '/../includes/db.php';       // SoulSync DB (soulsync)
require_once __DIR__ . '/../includes/helpers.php';
require_once __DIR__ . '/../includes/fcm.php';

function ss_admin_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// --- Auth guard: must be logged into the soulpages admin as admin/manager ---
$__role = $_SESSION['user_role'] ?? '';
if (!in_array($__role, ['admin', 'manager'], true)) {
    // Not an admin session → send to the soulpages admin login.
    header('Location: ../../admin/login.php');
    exit;
}

$SS_ADMIN_NAME = $_SESSION['user_name'] ?? 'Admin';
$SS_ROLE = ($__role === 'admin') ? 'owner' : 'manager';

function ss_is_owner() { return (($_SESSION['user_role'] ?? '') === 'admin'); }

// Managers may NOT see App Usage / Notifications / Tracking / Location.
function ss_require_owner() {
    if (!ss_is_owner()) { header('Location: index.php'); exit; }
}
